#ifndef CONNECTION_H
#define CONNECTION_H

#include <QTcpSocket>
#include <QtCore>
#include <string>
#include <QObject>
#include <vector>

#include "constants.h"
#include "player.h"

#define HOST "127.0.0.1"
#define PORT 21754

using namespace std;

class Connection : public QObject
{
    Q_OBJECT
public:
    explicit Connection(QObject* parent = 0);

    //For connecting to the server.
    void connect();

    //Api functions. The parameters passed by reference are return values.
    int reg(string user, string pass);
    int login(string user, string pass);
    int joinRand(int &roomId);
    int join(int roomId);
    int host(int &roomId);
    int check(int roomId);
    int getPlayers(int roomId, vector<Player> &players);
    int won(int roomId);
    int lost(int roomId);
    int getWord(int roomId, string &word);
    int getPlayerBoard(int roomId, string &pbString);
    int update(int roomId, Player &toUpdate);
    int getRooms(vector<int> &rooms);
    int getPlayerCount(int roomId, int& count);
    int unregister();

    void close();

private:
    void writeOp(int status);
    void writeString(string toWrite);
    void writeInt(int toWrite);

    string readString();
    int readStat();
    int readInt();

    //A function for printing not ok status.
    void notOk(int status);

    //For reconnecting if the server is disconnected.
    void checkConnection();

    QTcpSocket* socket;
    int fd;
};

#endif // CONNECTION_H
