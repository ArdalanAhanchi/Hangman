#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //Init to the login page.
    ui->stackedWidget->setCurrentIndex(0);

    //Init frame and player.
    setFrame(0);

    //Load the logo images into the labels.
    QPixmap img(LOGO_FILE);
    ui->logo_label->setPixmap(img.scaled(this->geometry().width(),
                            this->geometry().height(), Qt::KeepAspectRatio));
    ui->logo_label_2->setPixmap(img.scaled(this->geometry().width(),
                            this->geometry().height(), Qt::KeepAspectRatio));
    ui->logo_label_3->setPixmap(img.scaled(this->geometry().width(),
                           this->geometry().height(), Qt::KeepAspectRatio));

    //Initialize the buttons.
    connect(ui->login_button, SIGNAL(clicked()), this, SLOT(loginButtonClicked()));
    connect(ui->play_button, SIGNAL(clicked()), this, SLOT(playButtonClicked()));
    connect(ui->logout_button, SIGNAL(clicked()), this, SLOT(logoutButtonClicked()));
    connect(ui->menu_button, SIGNAL(clicked()), this, SLOT(menuButtonClicked()));
    connect(ui->register_button, SIGNAL(clicked()), this, SLOT(registerButtonClicked()));
    connect(ui->rooms_button, SIGNAL(clicked()), this, SLOT(roomsButtonClicked()));
    connect(ui->rooms_join_button, SIGNAL(clicked()), this, SLOT(roomJoinButtonClicked()));
    connect(ui->rooms_back_button, SIGNAL(clicked()), this, SLOT(roomBackButtonClicked()));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::registerButtonClicked()
{
    qDebug() << "Register Clicked!";
    string user = ui->user_lineEdit->text().toStdString();
    string pass = ui->pass_lineEdit->text().toStdString();

    //Login and check if the login was successful.
    if(connection.reg(user, pass) == S_OK)
    {
        player = Player("DefaultName");
        ui->stackedWidget->setCurrentIndex(1);
        ui->status_label->setText("Registration Successful.");
    }
    else
    {
        ui->status_label->setText("Registration Failed. Please Try Again.");
    }
}


void MainWindow::loginButtonClicked()
{
    qDebug() << "login Clicked!";
    string user = ui->user_lineEdit->text().toStdString();
    string pass = ui->pass_lineEdit->text().toStdString();

    if(user == "" || pass == "")
    {
        ui->status_label->setText("Invalid Info. Please Try Again.");
    }

    //Login and check if the login was successful.
    if(true)//connection.login(user, pass) == S_OK)
    {
        player = Player("DefaultName");
        ui->stackedWidget->setCurrentIndex(1);
        ui->status_label->setText("Login Successful.");
    }
    else
    {
        ui->status_label->setText("Login Failed. Please Try Again.");
    }
}

void MainWindow::playButtonClicked()
{
    qDebug() << "Play Clicked";
    ui->stackedWidget->setCurrentIndex(3);
    setFrame(5);
}

void MainWindow::logoutButtonClicked()
{
    qDebug() << "Logout Clicked!";
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::menuButtonClicked()
{
    qDebug() << "Menu Clicked!";
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::roomsButtonClicked()
{
    qDebug() << "Rooms Clicked!";
    ui->stackedWidget->setCurrentIndex(2);
}

void MainWindow::roomJoinButtonClicked()
{
    qDebug() << "Join Clicked!";
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::roomBackButtonClicked()
{
    qDebug() << "Back Clicked!";
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::setFrame(int level)
{
    //Check for invalid frame numbers.
    if(level >= NUMBER_OF_FRAMES)
    {
        cerr << "ERROR: Invalid level requested." << endl;
        return;
    }

    //Create a filename based on the given level.
    string fileName = FRAME_FILES_PREFIX;
    fileName.append(to_string(level));

    //Load the pixmap from file and set the frame.
    QPixmap img(fileName.c_str());
    ui->frame_img->setPixmap(img.scaled(ui->frame_img->width(),
                            ui->frame_img->height(), Qt::KeepAspectRatio));
}

