#include "connection.h"

Connection::Connection(QObject* parent) : QObject(parent)
{
    connect();
}

void Connection::connect()
{
    socket = new QTcpSocket(this);
    socket->connectToHost(HOST, PORT);

    if(socket->waitForConnected(30000))
        cerr << "Connection: Connected to Server." << endl;
    else
        cerr << "Connection: Couldn't connect to server." << endl;
}

int Connection::reg(string user, string pass)
{
    cerr << "Connection: Registering new client." << endl;
    checkConnection();
    writeOp(OP_CREATE_ACT);
    writeString(user);
    writeString(pass);
    socket->flush();
    return readStat();
}

int Connection::login(string user, string pass)
{
    checkConnection();
    writeOp(OP_LOGIN);
    writeString(user);
    writeString(pass);
    return readStat();
}

int Connection::joinRand(int &roomId)
{
    checkConnection();

    writeOp(OP_JOIN);
    int status = readStat();

    if(status == S_OK)
        roomId = readInt();
    else
        notOk(status);

    return status;
}

int Connection::join(int roomId)
{
    checkConnection();
    writeOp(OP_JOIN_RID);
    writeInt(roomId);
    return readStat();
}

int Connection::host(int &roomId)
{
    checkConnection();
    writeOp(OP_HOST);
    int status = readStat();
    if(status == S_OK)
        roomId = readInt();
    else
        notOk(status);

    return status;
}

int Connection::check(int roomId)
{
    checkConnection();
    writeOp(OP_CHECK_GAMEOVER);
    writeInt(roomId);
    return readStat();
}

int Connection::getPlayers(int roomId, vector<Player> &players)
{
    checkConnection();

    //Write the opcode.
    writeOp(OP_GET_PLAYERS);

    //Write the room number.
    writeInt(roomId);

    int status = readStat();
    if(status == S_OK)
    {
        //Read the number of elements, and then initialize the players.
        int numberOfElements = readInt();
        for(int i = 0; i < numberOfElements; i++)
        {
            Player newPlayer;
            newPlayer.deserialize(readString());
            players.push_back(newPlayer);
        }
    }
    else { notOk(status); }

    return status;
}

int Connection::won(int roomId)
{
    checkConnection();

    writeOp(OP_WON);
    writeInt(roomId);
    return readStat();
}

int Connection::lost(int roomId)
{
    checkConnection();

    writeOp(OP_LOST);
    writeInt(roomId);
    return readStat();
}

int Connection::getWord(int roomId, string &word)
{
    checkConnection();

    writeOp(OP_GET_WORD);
    writeInt(roomId);
    int status = readStat();

    if(status == S_OK)
        word = readString();
    else
        notOk(status);

    return status;
}

int Connection::getPlayerBoard(int roomId, string &pbString)
{
    checkConnection();

    writeOp(OP_GET_BOARD);
    writeInt(roomId);
    int status = readStat();

    if(status == S_OK)
        pbString = readString();
    else
        notOk(status);

    return status;
}

int Connection::update(int roomId, Player &toUpdate)
{
    checkConnection();

    writeOp(OP_UPDATE);
    writeInt(roomId);
    writeString(toUpdate.serialize());
    return readStat();
}

int Connection::getRooms(vector<int> &rooms)
{
    checkConnection();

    writeOp(OP_GET_ROOMS);
    int status = readStat();

    if(status == S_OK)
    {
        //Read the number of rooms, and then add each room to rooms.
        int numberOfElements = readInt();
        for(int i = 0; i < numberOfElements; i++)
            rooms.push_back(readInt());
    }
    else { notOk(status); }

    return status;
}

int Connection::getPlayerCount(int roomId, int &count)
{
    checkConnection();

    writeOp(OP_GET_PLAYER_COUNT);
    writeInt(roomId);
    int status = readStat();

    if(status == S_OK)
        count = readInt();

    return status;
}

int Connection::unregister()
{
    checkConnection();
    writeOp(OP_UNREGISTER);
    return readStat();
}

void Connection::close()
{
    socket->close();
    delete socket;
}

void Connection::writeOp(int status)
{
    char op = static_cast<char>(status);
    socket->write(&op, sizeof(op));
}

void Connection::writeString(string toWrite)
{
    int strSize = static_cast<char>(toWrite.size());
    writeInt(strSize);
    socket->write(toWrite.c_str());
}

int Connection::readStat()
{
    char status;
    socket->read(&status, sizeof(status));

    return static_cast<int>(status);
}

string Connection::readString()
{
    int strSize = readInt();

    char* buffer = new char[strSize];
    socket->read(buffer, strSize);

    string toReturn(buffer);
    delete[] buffer;

    return toReturn;
}

void Connection::writeInt(int toWrite)
{
    //QByteArray dataArr;
    //QDataStream dataStream(&dataArr, QIODevice::WriteOnly);
    //dataStream << toWrite;
    //socket->write(dataArr);
    socket->write(reinterpret_cast<const char*>(&toWrite), sizeof(toWrite));
}

int Connection::readInt()
{
    int toReturn = 0;
    socket->read(reinterpret_cast<char*>(&toReturn), sizeof(toReturn));
    return toReturn;
}

void Connection::notOk(int status)
{
   cerr << "Connection: ERROR: Server returned a " << status << endl;
}

void Connection::checkConnection()
{
    while(socket->state() != QTcpSocket::ConnectedState)
    {
        cerr << "Connection: ERROR: Server disconnected, reconnecting..." << endl;
        connect();
    }
}
